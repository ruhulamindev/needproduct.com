import DashboardStats from "@/components/admin/dashboard/dashboard-stats"
import RecentOrders from "@/components/admin/dashboard/recent-orders"
import SalesChart from "@/components/admin/dashboard/sales-chart"

export default function AdminDashboard() {
  return (
    <div className="space-y-5 md:space-y-6">
      <h1 className="text-xl md:text-3xl font-bold text-slate-800">Dashboard</h1>
      <DashboardStats />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 md:gap-6">
        <SalesChart />
        <RecentOrders />
      </div>
    </div>
  )
}